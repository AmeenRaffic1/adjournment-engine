<?php
if (!isset($page_title)) {
    $page_title = "SmartCause";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?= htmlspecialchars($page_title) ?>
        | SmartCause
    </title>

    <link
        rel="stylesheet"
        href="assets/css/style.css"
    >

</head>

<body>

<div class="app">

<?php include __DIR__ . "/sidebar.php"; ?>

<div class="main">

<header class="topbar">

    <div class="search">

        <span>⌕</span>

        <input
            type="text"
            placeholder="Search cases, CNR number..."
        >

    </div>

    <div class="top-user">

        <div class="notification">
            🔔
        </div>

        <div class="avatar">
            CL
        </div>

        <div>
            <strong>Court Clerk</strong>
            <small>Administrator</small>
        </div>

    </div>

</header>

<main class="content">