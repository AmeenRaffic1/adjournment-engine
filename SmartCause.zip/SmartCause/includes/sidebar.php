<aside class="sidebar">

    <div class="brand">

        <div class="brand-icon">
            SC
        </div>

        <div>
            <h2>SmartCause</h2>
            <span>Maharashtra Courts</span>
        </div>

    </div>

    <div class="menu-title">
        MAIN MENU
    </div>

    <nav>

        <a
            href="dashboard.php"
            class="nav-link"
        >
            <span>▦</span>
            Dashboard
        </a>

        <a
            href="cases.php"
            class="nav-link"
        >
            <span>▤</span>
            Case Management
        </a>

        <a
            href="courtrooms.php"
            class="nav-link"
        >
            <span>▥</span>
            Courtrooms
        </a>

        <a
            href="cause_list.php"
            class="nav-link"
        >
            <span>☷</span>
            Cause List
        </a>

        <a
            href="adjournments.php"
            class="nav-link"
        >
            <span>⚠</span>
            Adjournments
        </a>

        <a
            href="reoptimize.php"
            class="nav-link"
        >
            <span>⚡</span>
            Re-optimization
        </a>

        <a
            href="analytics.php"
            class="nav-link"
        >
            <span>◫</span>
            Analytics
        </a>

    </nav>

    <div class="sidebar-bottom">

        <div class="online-dot"></div>

        <div>
            <strong>System Online</strong>
            <small>All services operational</small>
        </div>

    </div>

</aside>