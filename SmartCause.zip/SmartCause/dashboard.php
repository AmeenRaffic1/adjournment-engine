<?php

require_once "config/database.php";

$page_title = "Dashboard";

$total_cases = 0;
$total_hearings = 0;
$total_adjournments = 0;

$result = $conn->query(
    "SELECT COUNT(*) AS total FROM cases"
);

if ($result) {
    $total_cases =
        $result->fetch_assoc()['total'];
}

$result = $conn->query(
    "SELECT COUNT(*) AS total
     FROM hearings
     WHERE hearing_date = CURDATE()"
);

if ($result) {
    $total_hearings =
        $result->fetch_assoc()['total'];
}

$result = $conn->query(
    "SELECT COUNT(*) AS total
     FROM adjournments
     WHERE DATE(adjourned_at) = CURDATE()"
);

if ($result) {
    $total_adjournments =
        $result->fetch_assoc()['total'];
}

require_once "includes/header.php";

?>

<div class="page-header">

    <div>

        <h1>
            Good evening, Clerk
        </h1>

        <p>
            Here's today's court scheduling overview.
        </p>

    </div>

    <a
        href="generate_schedule.php"
        class="primary-btn"
    >
        + Generate Cause List
    </a>

</div>

<div class="stats">

    <div class="card">

        <span class="stat-label">
            Active Cases
        </span>

        <div class="stat-number">
            <?= number_format($total_cases) ?>
        </div>

        <div class="stat-change">
            Court database
        </div>

    </div>

    <div class="card">

        <span class="stat-label">
            Today's Hearings
        </span>

        <div class="stat-number">
            <?= number_format($total_hearings) ?>
        </div>

        <div class="stat-change">
            Across 12 courtrooms
        </div>

    </div>

    <div class="card">

        <span class="stat-label">
            Today's Adjournments
        </span>

        <div class="stat-number">
            <?= number_format($total_adjournments) ?>
        </div>

        <div class="stat-change">
            Live status
        </div>

    </div>

    <div class="card">

        <span class="stat-label">
            Courtrooms
        </span>

        <div class="stat-number">
            12
        </div>

        <div class="stat-change">
            All operational
        </div>

    </div>

</div>

<div class="table-card">

    <div class="table-header">

        <div>

            <h2>
                Courtroom Overview
            </h2>

            <p>
                Current scheduling status
            </p>

        </div>

        <a
            href="courtrooms.php"
            class="secondary-btn"
        >
            View All
        </a>

    </div>

    <table>

        <thead>

            <tr>

                <th>COURTROOM</th>
                <th>JUDGE</th>
                <th>HEARINGS</th>
                <th>ADJOURNMENTS</th>
                <th>CAPACITY</th>
                <th>STATUS</th>

            </tr>

        </thead>

        <tbody>

        <?php

        $sql = "
            SELECT
                c.id,
                c.courtroom_name,
                c.judge_name,
                c.daily_capacity,

                COUNT(h.id) AS hearings,

                SUM(
                    CASE
                        WHEN h.status = 'Adjourned'
                        THEN 1
                        ELSE 0
                    END
                ) AS adjournments

            FROM courtrooms c

            LEFT JOIN hearings h
                ON c.id = h.courtroom_id
                AND h.hearing_date = CURDATE()

            GROUP BY c.id

            ORDER BY c.id
        ";

        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()):

            $hearings =
                (int)$row['hearings'];

            $capacity =
                round(
                    ($hearings / 35) * 100
                );

        ?>

            <tr>

                <td>
                    <strong>
                        <?= htmlspecialchars(
                            $row['courtroom_name']
                        ) ?>
                    </strong>
                </td>

                <td>
                    <?= htmlspecialchars(
                        $row['judge_name']
                    ) ?>
                </td>

                <td>
                    <?= $hearings ?>
                </td>

                <td>
                    <?= $row['adjournments'] ?? 0 ?>
                </td>

                <td>
                    <?= min($capacity, 100) ?>%
                </td>

                <td>

                    <?php if ($hearings >= 35): ?>

                        <span class="status red">
                            Full
                        </span>

                    <?php elseif ($hearings >= 28): ?>

                        <span class="status orange">
                            Near Capacity
                        </span>

                    <?php else: ?>

                        <span class="status green">
                            Normal
                        </span>

                    <?php endif; ?>

                </td>

            </tr>

        <?php endwhile; ?>

        </tbody>

    </table>

</div>

<?php

require_once "includes/footer.php";

?>