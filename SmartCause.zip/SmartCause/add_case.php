<?php

require_once "config/database.php";

$page_title = "Add Case";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $case_number =
        $_POST['case_number'];

    $cnr_number =
        $_POST['cnr_number'];

    $case_type =
        $_POST['case_type'];

    $case_subtype =
        $_POST['case_subtype'];

    $petitioner =
        $_POST['petitioner'];

    $respondent =
        $_POST['respondent'];

    $filing_date =
        $_POST['filing_date'];

    $registration_date =
        $_POST['registration_date'];

    $current_stage =
        $_POST['current_stage'];

    $next_hearing_date =
        $_POST['next_hearing_date'];

    $courtroom_id =
        $_POST['courtroom_id'];

    $outstation_witness =
        isset(
            $_POST['outstation_witness']
        ) ? 1 : 0;

    $accused_production_required =
        isset(
            $_POST['accused_production_required']
        ) ? 1 : 0;

    $accused_produced =
        isset(
            $_POST['accused_produced']
        ) ? 1 : 0;

    $documents_complete =
        isset(
            $_POST['documents_complete']
        ) ? 1 : 0;

    $urgent_bail =
        isset(
            $_POST['urgent_bail']
        ) ? 1 : 0;

    $lawyer_available =
        isset(
            $_POST['lawyer_available']
        ) ? 1 : 0;

    $previous_adjournments =
        (int)$_POST[
            'previous_adjournments'
        ];

    $risk = 0;

    if (!$lawyer_available)
        $risk += 25;

    if (
        $accused_production_required
        && !$accused_produced
    )
        $risk += 25;

    if (!$documents_complete)
        $risk += 20;

    if ($previous_adjournments >= 3)
        $risk += 15;
    elseif ($previous_adjournments >= 1)
        $risk += 8;

    if ($urgent_bail)
        $risk += 10;

    if ($outstation_witness)
        $risk += 5;

    $priority = 0;

    $age_days =
        (
            time()
            -
            strtotime($filing_date)
        ) / 86400;

    $age_years =
        $age_days / 365.25;

    if ($age_years > 5) {

        $priority += 50;

        $priority += min(
            ($age_years - 5) * 5,
            25
        );

    } else {

        $priority +=
            $age_years * 5;
    }

    if ($urgent_bail)
        $priority += 30;

    $priority += min(
        $previous_adjournments * 5,
        20
    );

    $priority =
        min($priority, 100);

    $sql = "
        INSERT INTO cases
        (
            case_number,
            cnr_number,
            case_type,
            case_subtype,
            petitioner,
            respondent,
            filing_date,
            registration_date,
            current_stage,
            next_hearing_date,
            courtroom_id,
            outstation_witness,
            accused_production_required,
            accused_produced,
            documents_complete,
            urgent_bail,
            lawyer_available,
            previous_adjournments,
            risk_score,
            priority_score
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ";

    $stmt =
        $conn->prepare($sql);

    $stmt->bind_param(
        "sssssssssi" .
        "iiiiiiiiii",
        $case_number,
        $cnr_number,
        $case_type,
        $case_subtype,
        $petitioner,
        $respondent,
        $filing_date,
        $registration_date,
        $current_stage,
        $next_hearing_date,
        $courtroom_id,
        $outstation_witness,
        $accused_production_required,
        $accused_produced,
        $documents_complete,
        $urgent_bail,
        $lawyer_available,
        $previous_adjournments,
        $risk,
        $priority
    );

    if ($stmt->execute()) {

        header(
            "Location: cases.php"
        );

        exit;

    } else {

        $message =
            "Error: " .
            $stmt->error;
    }
}

require_once "includes/header.php";

?>

<div class="page-header">

    <div>

        <h1>Add New Case</h1>

        <p>
            Enter case metadata used by the scheduling engine.
        </p>

    </div>

</div>

<?php if ($message): ?>

<div class="status red">
    <?= htmlspecialchars($message) ?>
</div>

<?php endif; ?>

<form
    method="POST"
    class="form-card"
>

    <div class="form-grid">

        <div class="form-group">

            <label>
                Case Number *
            </label>

            <input
                type="text"
                name="case_number"
                placeholder="CR/2026/00125"
                required
            >

        </div>

        <div class="form-group">

            <label>
                CNR Number *
            </label>

            <input
                type="text"
                name="cnr_number"
                placeholder="MHXX010012342026"
                required
            >

        </div>

        <div class="form-group">

            <label>
                Case Type *
            </label>

            <select
                name="case_type"
                required
            >

                <option value="">
                    Select Case Type
                </option>

                <option value="Criminal">
                    Criminal
                </option>

                <option value="Civil">
                    Civil
                </option>

                <option value="Bail">
                    Bail
                </option>

                <option value="Appeal">
                    Appeal
                </option>

                <option value="Evidence">
                    Evidence
                </option>

                <option value="Miscellaneous">
                    Miscellaneous
                </option>

            </select>

        </div>

        <div class="form-group">

            <label>
                Case Sub-Type
            </label>

            <input
                type="text"
                name="case_subtype"
                placeholder="Regular Bail"
            >

        </div>

        <div class="form-group">

            <label>
                Petitioner
            </label>

            <input
                type="text"
                name="petitioner"
            >

        </div>

        <div class="form-group">

            <label>
                Respondent
            </label>

            <input
                type="text"
                name="respondent"
            >

        </div>

        <div class="form-group">

            <label>
                Filing Date
            </label>

            <input
                type="date"
                name="filing_date"
                required
            >

        </div>

        <div class="form-group">

            <label>
                Registration Date
            </label>

            <input
                type="date"
                name="registration_date"
            >

        </div>

        <div class="form-group">

            <label>
                Current Stage
            </label>

            <select name="current_stage">

                <option>
                    Admission
                </option>

                <option>
                    Evidence
                </option>

                <option>
                    Arguments
                </option>

                <option>
                    Judgment
                </option>

                <option>
                    Bail Hearing
                </option>

            </select>

        </div>

        <div class="form-group">

            <label>
                Next Hearing Date
            </label>

            <input
                type="date"
                name="next_hearing_date"
            >

        </div>

        <div class="form-group">

            <label>
                Courtroom
            </label>

            <select name="courtroom_id">

                <?php

                $rooms =
                    $conn->query(
                        "SELECT *
                         FROM courtrooms
                         ORDER BY id"
                    );

                while (
                    $room =
                    $rooms->fetch_assoc()
                ):

                ?>

                    <option
                        value="<?= $room['id'] ?>"
                    >
                        <?= htmlspecialchars(
                            $room['courtroom_name']
                        ) ?>
                    </option>

                <?php endwhile; ?>

            </select>

        </div>

        <div class="form-group">

            <label>
                Previous Adjournments
            </label>

            <input
                type="number"
                name="previous_adjournments"
                min="0"
                value="0"
            >

        </div>

        <div class="form-group full">

            <label>
                Scheduling Metadata
            </label>

            <div class="checkbox-row">

                <label>
                    <input
                        type="checkbox"
                        name="outstation_witness"
                    >
                    Outstation Witness
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="accused_production_required"
                    >
                    Accused Production Required
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="accused_produced"
                        checked
                    >
                    Accused Produced
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="documents_complete"
                        checked
                    >
                    Documents Complete
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="urgent_bail"
                    >
                    Urgent Bail
                </label>

                <label>
                    <input
                        type="checkbox"
                        name="lawyer_available"
                        checked
                    >
                    Lawyer Available
                </label>

            </div>

        </div>

    </div>

    <div class="form-actions">

        <a
            href="cases.php"
            class="secondary-btn"
        >
            Cancel
        </a>

        <button
            type="submit"
            class="primary-btn"
        >
            Save Case
        </button>

    </div>

</form>

<?php

require_once "includes/footer.php";

?>