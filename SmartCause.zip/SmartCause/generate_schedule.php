<?php

require_once "config/database.php";

date_default_timezone_set("Asia/Kolkata");

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $startTime = microtime(true);

    $scheduleDate = $_POST["schedule_date"] ?? date("Y-m-d");

    /*
    ---------------------------------------------------------
    STEP 1: Clear previous schedule for this date
    ---------------------------------------------------------
    */

    $deleteOld = $conn->prepare("
        DELETE FROM hearings
        WHERE hearing_date = ?
    ");

    $deleteOld->bind_param("s", $scheduleDate);
    $deleteOld->execute();
    $deleteOld->close();


    /*
    ---------------------------------------------------------
    STEP 2: Get all courtrooms
    ---------------------------------------------------------
    */

    $courtrooms = [];

    $roomResult = $conn->query("
        SELECT id, courtroom_number, judge_name
        FROM courtrooms
        ORDER BY id
    ");

    while ($room = $roomResult->fetch_assoc()) {

        $courtrooms[$room["id"]] = [
            "id" => $room["id"],
            "number" => $room["courtroom_number"],
            "judge" => $room["judge_name"],
            "count" => 0
        ];
    }


    /*
    ---------------------------------------------------------
    STEP 3: Get eligible cases
    ---------------------------------------------------------
    */

    $cases = [];

    $caseQuery = "
        SELECT
            c.*,
            (
                SELECT MAX(a.adjourned_at)
                FROM adjournments a
                WHERE a.case_id = c.id
            ) AS last_adjournment
        FROM cases c
        WHERE c.next_hearing_date <= ?
        ORDER BY c.priority_score DESC
    ";

    $stmt = $conn->prepare($caseQuery);
    $stmt->bind_param("s", $scheduleDate);
    $stmt->execute();

    $result = $stmt->get_result();

    while ($case = $result->fetch_assoc()) {
        $cases[] = $case;
    }

    $stmt->close();


    /*
    ---------------------------------------------------------
    STEP 4: Sort cases intelligently
    ---------------------------------------------------------

    Priority order:

    1. Urgent bail
    2. Older cases
    3. Higher priority score
    4. Higher risk score
    */

    usort($cases, function ($a, $b) {

        $aBail = (
            strtolower($a["case_type"]) === "bail" ||
            stripos($a["subtype"], "bail") !== false
        ) ? 1 : 0;

        $bBail = (
            strtolower($b["case_type"]) === "bail" ||
            stripos($b["subtype"], "bail") !== false
        ) ? 1 : 0;

        if ($aBail != $bBail) {
            return $bBail - $aBail;
        }

        $aAge = strtotime($a["filing_date"]);
        $bAge = strtotime($b["filing_date"]);

        if ($aAge != $bAge) {
            return $aAge - $bAge;
        }

        if ($a["priority_score"] != $b["priority_score"]) {
            return $b["priority_score"] - $a["priority_score"];
        }

        return $b["risk_score"] - $a["risk_score"];
    });


    /*
    ---------------------------------------------------------
    STEP 5: Define time slots
    ---------------------------------------------------------
    */

    $morningSlots = [
        "09:30:00",
        "09:45:00",
        "10:00:00",
        "10:15:00",
        "10:30:00",
        "10:45:00"
    ];

    $afternoonSlots = [
        "14:00:00",
        "14:15:00",
        "14:30:00",
        "14:45:00",
        "15:00:00",
        "15:15:00",
        "15:30:00",
        "15:45:00",
        "16:00:00",
        "16:15:00",
        "16:30:00",
        "16:45:00",
        "17:00:00",
        "17:15:00",
        "17:30:00",
        "17:45:00",
        "18:00:00",
        "18:15:00",
        "18:30:00",
        "18:45:00",
        "19:00:00"
    ];


    /*
    ---------------------------------------------------------
    STEP 6: Prepare insert statement
    ---------------------------------------------------------
    */

    $insert = $conn->prepare("
        INSERT INTO hearings
        (
            case_id,
            hearing_date,
            scheduled_time,
            courtroom_id,
            status
        )
        VALUES (?, ?, ?, ?, 'Scheduled')
    ");


    /*
    ---------------------------------------------------------
    STEP 7: Schedule cases
    ---------------------------------------------------------
    */

    $scheduled = 0;
    $standby = 0;
    $conflicts = 0;

    $standbyCases = [];

    foreach ($cases as $case) {

        /*
        ---------------------------------------------
        Check 48-hour outstation witness protection
        ---------------------------------------------
        */

        if (
            !empty($case["outstation_witness"]) &&
            !empty($case["last_adjournment"])
        ) {

            $lastAdjournment = strtotime($case["last_adjournment"]);
            $allowedTime = $lastAdjournment + (48 * 60 * 60);

            $targetTime = strtotime($scheduleDate . " 09:30:00");

            if ($targetTime < $allowedTime) {

                $standbyCases[] = [
                    "case" => $case,
                    "reason" => "48-hour outstation witness protection"
                ];

                $standby++;
                continue;
            }
        }


        /*
        ---------------------------------------------
        Determine whether this is a bail matter
        ---------------------------------------------
        */

        $isBail = (
            strtolower($case["case_type"]) === "bail" ||
            stripos($case["subtype"], "bail") !== false
        );


        /*
        ---------------------------------------------
        Find available courtroom
        ---------------------------------------------
        */

        $selectedRoom = null;
        $selectedTime = null;


        /*
        ---------------------------------------------
        BAIL CASES
        Must be before 11 AM
        ---------------------------------------------
        */

        if ($isBail) {

            foreach ($morningSlots as $slot) {

                foreach ($courtrooms as $roomId => $room) {

                    if ($room["count"] >= 35) {
                        continue;
                    }

                    /*
                    Prevent two cases in same courtroom
                    at exactly the same time.
                    */

                    $check = $conn->prepare("
                        SELECT COUNT(*) AS total
                        FROM hearings
                        WHERE hearing_date = ?
                        AND courtroom_id = ?
                        AND scheduled_time = ?
                    ");

                    $check->bind_param(
                        "sis",
                        $scheduleDate,
                        $roomId,
                        $slot
                    );

                    $check->execute();

                    $checkResult = $check->get_result()->fetch_assoc();

                    $check->close();

                    if ($checkResult["total"] == 0) {

                        $selectedRoom = $roomId;
                        $selectedTime = $slot;

                        break 2;
                    }
                }
            }

        } else {

            /*
            -----------------------------------------
            NORMAL CASES
            -----------------------------------------
            */

            foreach ($afternoonSlots as $slot) {

                foreach ($courtrooms as $roomId => $room) {

                    if ($room["count"] >= 35) {
                        continue;
                    }

                    $check = $conn->prepare("
                        SELECT COUNT(*) AS total
                        FROM hearings
                        WHERE hearing_date = ?
                        AND courtroom_id = ?
                        AND scheduled_time = ?
                    ");

                    $check->bind_param(
                        "sis",
                        $scheduleDate,
                        $roomId,
                        $slot
                    );

                    $check->execute();

                    $checkResult = $check->get_result()->fetch_assoc();

                    $check->close();

                    if ($checkResult["total"] == 0) {

                        $selectedRoom = $roomId;
                        $selectedTime = $slot;

                        break 2;
                    }
                }
            }
        }


        /*
        ---------------------------------------------
        If no slot is available → standby
        ---------------------------------------------
        */

        if ($selectedRoom === null) {

            $standbyCases[] = [
                "case" => $case,
                "reason" => "No available courtroom/time slot"
            ];

            $standby++;
            continue;
        }


        /*
        ---------------------------------------------
        Insert scheduled hearing
        ---------------------------------------------
        */

        $caseId = $case["id"];

        $insert->bind_param(
            "issi",
            $caseId,
            $scheduleDate,
            $selectedTime,
            $selectedRoom
        );

        $insert->execute();


        /*
        ---------------------------------------------
        Update courtroom count
        ---------------------------------------------
        */

        $courtrooms[$selectedRoom]["count"]++;

        $scheduled++;
    }

    $insert->close();


    /*
    ---------------------------------------------------------
    STEP 8: Save schedule version
    ---------------------------------------------------------
    */

    $executionTime = round(microtime(true) - $startTime, 4);

    $versionName = "Optimized Schedule - " . date("d M Y H:i:s");

    $versionStmt = $conn->prepare("
        INSERT INTO schedule_versions
        (
            schedule_date,
            version_name,
            generated_at
        )
        VALUES (?, ?, NOW())
    ");

    $versionStmt->bind_param(
        "ss",
        $scheduleDate,
        $versionName
    );

    $versionStmt->execute();
    $versionStmt->close();


    /*
    ---------------------------------------------------------
    STEP 9: Save audit log
    ---------------------------------------------------------
    */

    $action = "Schedule generated";

    $details =
        "Optimized schedule generated. " .
        "Scheduled: " . $scheduled .
        ", Standby: " . $standby .
        ", Execution time: " . $executionTime . " seconds.";

    $audit = $conn->prepare("
        INSERT INTO audit_logs
        (
            action,
            details,
            created_at
        )
        VALUES (?, ?, NOW())
    ");

    $audit->bind_param(
        "ss",
        $action,
        $details
    );

    $audit->execute();
    $audit->close();


    /*
    ---------------------------------------------------------
    STEP 10: Store standby cases in session
    ---------------------------------------------------------
    */

    session_start();

    $_SESSION["standby_cases"] = $standbyCases;

    $_SESSION["schedule_summary"] = [
        "scheduled" => $scheduled,
        "standby" => $standby,
        "conflicts" => $conflicts,
        "execution_time" => $executionTime,
        "date" => $scheduleDate
    ];


    $message =
        "Schedule generated successfully! " .
        $scheduled .
        " cases scheduled and " .
        $standby .
        " cases placed in standby. " .
        "Processing time: " .
        $executionTime .
        " seconds.";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Generate Cause List - SmartCause</title>

    <link rel="stylesheet"
          href="assets/css/style.css">

</head>

<body>

<?php include "includes/header.php"; ?>

<div class="main-content">

    <div class="page-header">

        <div>

            <h1>Generate Cause List</h1>

            <p>
                AI-assisted optimized daily courtroom scheduling
            </p>

        </div>

    </div>


    <?php if ($message): ?>

        <div class="alert success">

            <?php echo htmlspecialchars($message); ?>

        </div>

    <?php endif; ?>


    <?php if ($error): ?>

        <div class="alert danger">

            <?php echo htmlspecialchars($error); ?>

        </div>

    <?php endif; ?>


    <div class="card">

        <div class="card-header">

            <h2>Generate Optimized Schedule</h2>

        </div>

        <div class="card-body">

            <p>
                SmartCause will automatically apply the following
                constraints:
            </p>

            <ul>

                <li>
                    Criminal bail matters before 11:00 AM
                </li>

                <li>
                    48-hour protection for outstation witnesses
                </li>

                <li>
                    Maximum 35 matters per judge
                </li>

                <li>
                    Older cases receive higher priority
                </li>

                <li>
                    High-risk and urgent matters receive additional priority
                </li>

                <li>
                    Unscheduled cases are moved to a standby pool
                </li>

            </ul>


            <form method="POST">

                <div class="form-group">

                    <label>
                        Cause List Date
                    </label>

                    <input
                        type="date"
                        name="schedule_date"
                        value="<?php echo date("Y-m-d"); ?>"
                        required
                    >

                </div>


                <button
                    type="submit"
                    class="btn btn-primary">

                    Generate Optimized Cause List

                </button>

            </form>

        </div>

    </div>


    <?php

    if (
        isset($_SESSION["schedule_summary"])
        &&
        $_SESSION["schedule_summary"]["date"]
        === $scheduleDate
    ):

        $summary = $_SESSION["schedule_summary"];

    ?>

    <div class="stats-grid">

        <div class="stat-card">

            <div class="stat-title">
                Scheduled
            </div>

            <div class="stat-value">
                <?php echo $summary["scheduled"]; ?>
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-title">
                Standby
            </div>

            <div class="stat-value">
                <?php echo $summary["standby"]; ?>
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-title">
                Execution Time
            </div>

            <div class="stat-value">

                <?php
                echo $summary["execution_time"];
                ?>

                <small>sec</small>

            </div>

        </div>


        <div class="stat-card">

            <div class="stat-title">
                Courtrooms
            </div>

            <div class="stat-value">
                12
            </div>

        </div>

    </div>

    <?php endif; ?>


    <div class="card">

        <div class="card-header">

            <h2>Scheduling Logic</h2>

        </div>

        <div class="card-body">

            <p>
                <strong>Priority:</strong>
                Older cases → urgent bail → high-risk cases →
                previous adjournments.
            </p>

            <p>
                <strong>Capacity:</strong>
                Each courtroom/judge can handle a maximum of
                35 matters.
            </p>

            <p>
                <strong>Bail protection:</strong>
                Bail matters are assigned only to morning slots
                before 11:00 AM.
            </p>

            <p>
                <strong>Witness protection:</strong>
                Cases involving outstation witnesses are not
                rescheduled within the protected 48-hour period.
            </p>

        </div>

    </div>

</div>

<?php include "includes/footer.php"; ?>

</body>

</html>
