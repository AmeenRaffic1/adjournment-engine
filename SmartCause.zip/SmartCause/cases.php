<?php

require_once "config/database.php";

$page_title = "Case Management";

require_once "includes/header.php";

?>

<div class="page-header">

    <div>

        <h1>Case Management</h1>

        <p>
            Manage active court cases and scheduling metadata.
        </p>

    </div>

    <div>

        <a
            href="import_cases.php"
            class="secondary-btn"
        >
            Import Cases
        </a>

        <a
            href="add_case.php"
            class="primary-btn"
        >
            + Add New Case
        </a>

    </div>

</div>

<div class="table-card">

    <div class="table-header">

        <div>

            <h2>Active Cases</h2>

            <p>
                Cases prioritized by scheduling importance
            </p>

        </div>

    </div>

    <table>

        <thead>

            <tr>

                <th>CASE NUMBER</th>
                <th>CNR NUMBER</th>
                <th>TYPE</th>
                <th>FILING DATE</th>
                <th>RISK</th>
                <th>PRIORITY</th>
                <th>ACTIONS</th>

            </tr>

        </thead>

        <tbody>

        <?php

        $sql = "
            SELECT *
            FROM cases
            ORDER BY priority_score DESC
        ";

        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0):

            while ($case = $result->fetch_assoc()):

        ?>

            <tr>

                <td>
                    <strong>
                        <?= htmlspecialchars(
                            $case['case_number']
                        ) ?>
                    </strong>
                </td>

                <td>
                    <?= htmlspecialchars(
                        $case['cnr_number']
                    ) ?>
                </td>

                <td>
                    <?= htmlspecialchars(
                        $case['case_type']
                    ) ?>
                </td>

                <td>
                    <?= htmlspecialchars(
                        $case['filing_date']
                    ) ?>
                </td>

                <td>

                    <?php

                    $risk =
                        (float)$case['risk_score'];

                    ?>

                    <?php if ($risk >= 60): ?>

                        <span class="status red">
                            High
                        </span>

                    <?php elseif ($risk >= 30): ?>

                        <span class="status orange">
                            Medium
                        </span>

                    <?php else: ?>

                        <span class="status green">
                            Low
                        </span>

                    <?php endif; ?>

                </td>

                <td>
                    <?= number_format(
                        $case['priority_score'],
                        1
                    ) ?>
                </td>

                <td>

                    <a
                        href="edit_case.php?id=<?= $case['id'] ?>"
                    >
                        Edit
                    </a>

                    |

                    <a
                        href="delete_case.php?id=<?= $case['id'] ?>"
                        onclick="
                        return confirm(
                            'Delete this case?'
                        );
                        "
                    >
                        Delete
                    </a>

                </td>

            </tr>

        <?php

            endwhile;

        else:

        ?>

            <tr>

                <td
                    colspan="7"
                    style="text-align:center;"
                >
                    No cases found.
                    Add cases or import your test dataset.
                </td>

            </tr>

        <?php endif; ?>

        </tbody>

    </table>

</div>

<?php

require_once "includes/footer.php";

?>